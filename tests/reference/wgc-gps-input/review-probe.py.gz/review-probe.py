"""Independent read-only WGC calendar probes; writes only this scratch directory.

The wide corpus compares native TIMOUT month/day/DOY/time components. TIMOUT
YYYY has fixed width, unlike the independently observed WGC extended years;
therefore year presentation is excluded from that comparison. Calendar year
values are separately checked using native ETCAL/ET2UTC, without asserting that
these secondary functions reproduce TIMOUT's subsecond rounding.
"""
from pathlib import Path
import datetime, hashlib, importlib, json, math, platform, random, re, sys
import spiceypy as spice
import spiceypy.utils.libspicehelper as helper

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
assert OUT == ROOT / 'target' / 'review-gps-evidence'
sys.path.insert(0, str(ROOT / 'target/python-wgc-input-venv/Lib/site-packages'))
time = importlib.import_module('stkcraft_time')
LSK = ROOT / 'src/naif0012.tls'
SOURCE = ROOT / 'src/wgc_gps.rs'
NATIVE_SOURCE = Path('C:/Users/stone/.codex/worktrees/dsk-models-parity/STKCraft-Geocalc/target/reference/n0067/cspice/src/cspice')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory():
    paths = list((ROOT / 'src').rglob('*.rs'))
    paths += [Path(__file__), LSK, ROOT / 'bindings/python/src/lib.rs',
              ROOT / 'bindings/python/python/stkcraft_time/__init__.py',
              Path(time.__file__), Path(time.__file__).parent / '_native.pyd',
              Path(helper.libspice._name)]
    paths += [NATIVE_SOURCE / x for x in ('timout.c', 'ttrans.c', 'unitim.c', 'rmaind.c', 'etcal.c', 'et2utc.c')]
    return {str(p.resolve()): {'sha256': digest(p), 'size': p.stat().st_size,
                              'mtime_ns': p.stat().st_mtime_ns} for p in paths}

YEAR = re.compile(r'^\s*(?:-?\d+|\*+)(?: BC| AD)?-')
RUST_YEAR = re.compile(r'^(\d+)(?: (BC|AD))?-')
NATIVE_YEAR = re.compile(r'^\s*(\d+)(?:\s+(B\.C\.|A\.D\.))?\s')
HALF_MICRO = 0.5
for _ in range(6):
    HALF_MICRO *= 0.1

def year_value(text, native=False):
    match = (NATIVE_YEAR if native else RUST_YEAR).match(text)
    if match is None:
        raise ValueError('Unrecognized calendar year: ' + text)
    number = int(match[1])
    return 1 - number if match[2] in ('BC', 'B.C.') else number

def rust_calendar(et, system, lsk, ymd):
    function = time.et_to_wgc_calendar_ymd if ymd else time.et_to_wgc_calendar_doy
    try:
        return function(time.NaifEt(et), system, lsk)
    except time.TimeError as error:
        return 'E:' + str(error)

def native_calendar(source, scale, system, ymd):
    picture = ('YYYY-MM-DD HR:MN:SC.######' if ymd else 'YYYY-DOY/HR:MN:SC.######') + ' ::' + scale + ' ::RND'
    try:
        return spice.timout(source, picture) + ' ' + system
    except spice.utils.exceptions.SpiceyError as error:
        return 'E:' + error.short

def emit(stream, row):
    stream.write(json.dumps(row, ensure_ascii=True) + '\n')

before = inventory()
spice.kclear()
spice.furnsh(str(LSK))
lsk = time.LeapSecondTable.from_file(LSK)
rng = random.Random(133711)
values = [rng.uniform(-1e12, 1e12) for _ in range(1400)]
values += [rng.uniform(-1e14, 1e14) for _ in range(600)]
values += [n * 86400. - 43200. + x
           for n in [-1000000, -10000, -1, 0, 1, 10000, 1000000]
           for x in [-.000001, -.0000005, -.00000049, 0., .00000049, .0000005, .000001]]
wide = {'input_count': len(values), 'comparisons': 0, 'raw_full_string_differences': 0,
        'component_mismatches': 0, 'calendar_year_mismatches': 0, 'examples': []}
with (OUT / 'wide-results.jsonl').open('w', encoding='ascii', newline='\n') as stream:
    for et in values:
        for system in ['UTC', 'TDB', 'TT', 'TDT', 'GPS']:
            source = spice.unitim(et, 'TDB', 'TAI') - 19. if system == 'GPS' else et
            scale = 'TDT' if system in ['TT', 'TDT'] else 'TDB' if system == 'GPS' else system
            if system == 'UTC':
                year_reference = spice.et2utc(et, 'C', 6, 128)
                year_reference_kind = 'ET2UTC(C), year only'
            else:
                uniform = spice.unitim(et, 'TDB', 'TDT') if system in ['TT', 'TDT'] else source
                year_reference = spice.etcal(uniform + HALF_MICRO)
                year_reference_kind = 'ETCAL(uniform + native half-micro), year only'
            for ymd in [False, True]:
                native = native_calendar(source, scale, system, ymd)
                actual = rust_calendar(et, system, lsk, ymd)
                components_match = YEAR.sub('', native) == YEAR.sub('', actual)
                years_match = year_value(actual) == year_value(year_reference, native=True)
                row = {'et': repr(et), 'et_hex': et.hex(), 'system': system,
                       'style': 'YMD' if ymd else 'DOY', 'native_timout': native,
                       'rust_output': actual, 'components_match': components_match,
                       'native_year_reference': year_reference,
                       'native_year_reference_kind': year_reference_kind,
                       'calendar_year_match': years_match}
                emit(stream, row)
                wide['comparisons'] += 1
                wide['raw_full_string_differences'] += actual != native
                wide['component_mismatches'] += not components_match
                wide['calendar_year_mismatches'] += not years_match
                if (not components_match or not years_match) and len(wide['examples']) < 30:
                    wide['examples'].append(row)

base = LSK.read_text(encoding='utf-8')
altered = {'profiles': [35, 36, 38, 40, 0, -100], 'comparisons': 0,
           'full_string_mismatches': 0, 'examples': []}
with (OUT / 'altered-leaps-results.jsonl').open('w', encoding='ascii', newline='\n') as stream:
    for offset in altered['profiles']:
        text, replaced = re.subn(r'37,\s+@2017-JAN-1', f'{offset}, @2017-JAN-1', base)
        assert replaced == 1
        kernel_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
        lsk = time.LeapSecondTable.from_lsk(text)
        spice.kclear()
        spice.furnsh(str(LSK))
        table = spice.gdpool('DELTET/DELTA_AT', 0, 1000)
        table[-2] = offset
        spice.pdpool('DELTET/DELTA_AT', table)
        epoch = spice.str2et('2017-JAN-1 00:00:00 UTC')
        values = [epoch + j / 32 for j in range(-2048, 2049)]
        values += [epoch + v for v in [-.000001, -.0000005, -.00000049, 0., .00000049, .0000005, .000001]]
        for et in values:
            for ymd in [False, True]:
                native = native_calendar(et, 'UTC', 'UTC', ymd)
                actual = rust_calendar(et, 'UTC', lsk, ymd)
                row = {'offset_2017': offset, 'rust_lsk_text_sha256': kernel_hash,
                       'et': repr(et), 'et_hex': et.hex(), 'style': 'YMD' if ymd else 'DOY',
                       'native_timout': native, 'rust_output': actual, 'match': actual == native}
                emit(stream, row)
                altered['comparisons'] += 1
                altered['full_string_mismatches'] += actual != native
                if actual != native and len(altered['examples']) < 30:
                    altered['examples'].append(row)

after = inventory()
report = {'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'python': sys.version, 'platform': platform.platform(),
          'spiceypy': spice.__version__, 'toolkit': spice.tkvrsn('TOOLKIT'),
          'adapter_version': time.__version__, 'adapter_path': time.__file__,
          'scope': 'Installed Python Rust adapter versus local CSPICE; no NASA HTTP requests in this script.',
          'wide_year_caveat': 'Raw TIMOUT YYYY year presentation differs from WGC extended AD/BC year presentation. Component comparisons exclude that prefix; astronomical calendar years are separately checked using the recorded native year references. ETCAL/ET2UTC subsecond strings are not treated as TIMOUT rounding oracles.',
          'source_inventory_before': before, 'source_inventory_after': after,
          'inventory_unchanged': before == after, 'wide': wide, 'altered_leaps': altered,
          'files': {name: digest(OUT / name) for name in ('probe.py', 'wide-results.jsonl', 'altered-leaps-results.jsonl')}}
(OUT / 'metadata.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'output_dir': str(OUT), 'wide': wide, 'altered_leaps': altered,
                  'inventory_unchanged': before == after,
                  'metadata_sha256': digest(OUT / 'metadata.json')}, indent=2))
